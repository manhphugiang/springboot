export class Item {
    id?: number;
    name?: string;
    employeeName?: string;
    price?: number;
    quantity?: number;
}
