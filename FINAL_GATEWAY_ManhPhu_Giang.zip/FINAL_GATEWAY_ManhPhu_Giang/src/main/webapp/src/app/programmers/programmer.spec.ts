import { Programmer } from './programmer';

describe('Programmer', () => {
  it('should create an instance', () => {
    expect(new Programmer()).toBeTruthy();
  });
});
