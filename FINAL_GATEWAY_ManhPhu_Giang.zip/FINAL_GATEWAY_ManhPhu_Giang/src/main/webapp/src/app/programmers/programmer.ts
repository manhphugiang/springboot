export class Programmer {
    id?: number;
    name?: string;
}
