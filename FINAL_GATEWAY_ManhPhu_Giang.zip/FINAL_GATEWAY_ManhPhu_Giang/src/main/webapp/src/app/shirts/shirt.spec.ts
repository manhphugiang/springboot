import { Shirt } from './shirt';

describe('Shirt', () => {
  it('should create an instance', () => {
    expect(new Shirt()).toBeTruthy();
  });
});
