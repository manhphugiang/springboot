package ca.sheridancollege.giangma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalMicro2ManhPhuGiangApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalMicro2ManhPhuGiangApplication.class, args);
	}

}
