package ca.sheridancollege.giangma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MidtermWebManhPhuGiangApplication {

	public static void main(String[] args) {
		SpringApplication.run(MidtermWebManhPhuGiangApplication.class, args);
	}

}
